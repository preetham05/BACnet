.. BACpypes tutorial lesson 4

Addressing
==========

BACnet addresses come in five delicious flavors:

* local station - 
* local broadcast -
* remote station -
* remote broadcast -
* global broadcast -

