.. BACpypes console command module

.. module:: consolecmd

Console Command
===============

This is a long line of text.

Functions
---------

.. function:: console_interrupt(*args)

    :param args:

Classes
-------

.. class:: ConsoleCmd(cmd.Cmd, Thread)

    This is a long line of text.

    .. method:: __init__(prompt="> ", allow_exec=False)

        :param string prompt: prompt for commands
        :param boolean allow_exec: allow non-commands to be executed

        This is a long line of text.

    .. method:: run()

        This is a long line of text.

    .. method:: do_something(args)

        :param args: commands

        This is a long line of text.

Commands
--------

.. option:: gc

    This is a long line of text.

.. option:: bugin <name>

    This is a long line of text.

.. option:: bugout <name>

    This is a long line of text.

.. option:: buggers

    This is a long line of text.

.. option:: exit

    This is a long line of text.
