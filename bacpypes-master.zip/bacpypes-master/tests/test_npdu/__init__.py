#!/usr/bin/python

"""
Test Network Layer Encoding and Decoding
"""

from . import test_codec

